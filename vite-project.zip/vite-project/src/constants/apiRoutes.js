export const API_PATHS = {
  GET_USERS: "/users",
  // Add more paths here as needed
};
