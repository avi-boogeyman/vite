export const TEXT_ERROR = "text-[#ff4d4f]";

export const FORM_STYLES = {
  GROUP: `mb-4`,
  LABEL: `leading-6 font-medium`,
  ERROR: `${TEXT_ERROR} mt-0.5 pl-2`,
};
