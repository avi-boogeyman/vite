import { Typography } from "antd";
const { Title } = Typography;

const Home = () => {
  return <Title level={3}>Home</Title>;
};

export default Home;
